<?php
    session_start();
    session_destroy();
    echo "Anda telah sukses keluar sistem <b>LOGOUT</b>";
?>