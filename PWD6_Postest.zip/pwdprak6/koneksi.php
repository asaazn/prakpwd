<?php
    #server yang di pakai
    $host = "localhost";
    #username default yang di pakai server
    $username = "root";
    #password default yang di pakai
    $password = "";
    #database yang dipakai
    $databasename = "akademik";
    #Untuk membuat koneksi
    $con = @mysqli_connect($host, $username, $password, $databasename);

    #cek koneksi
    if (!$con) {
        #tampilkan pesan error jika gagal terkoneksi
        echo "Error: " . mysqli_connect_error();
        #untuk membuat proses berhenti
        exit();
    }
?>