<?php
    echo "<h2>User</h2>
    <form method=POST action=form_user.php>
    <input type=submit value='Tambah User'>
    </form>
    <table border=1>
    <tr><th>No</th><th>Username</th><th>NamaLengkap</th><th>Email</th><th>Aksi</th></tr>";
    
    #digunakan untuk koneksi ke database
    include "koneksi.php";
    #memanggil perintah tampilkan data dari is_user
    $sql = "select * from users order by id_user";
    #untuk mengirimkan perintah query
    $tampil = mysqli_query($con, $sql);
    #mengambil jumlah baris pada tabel
    if (mysqli_num_rows($tampil) > 0) {
        $no = 1;
        while ($r = mysqli_fetch_array($tampil)) {
            #mengambil hasil baris sebagai asosiatif
            echo "<tr><td>$no</td><td>$r[id_user]</td>
            <td>$r[nama_lengkap]</td>
            <td>$r[email]</td>
            <td>$r[riwayat]</td>
            <td><a href='hapus_user.php?id=$r[id_user]'>Hapus</a></td>
            </tr>";
            $no++;
        }
        echo "</table>";
    } else {
        echo "0 results";
    }
    #untuk menutup koneksi
    mysqli_close($con);
?>