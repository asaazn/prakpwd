<?php
    #untuk menjalankan perintah pada server dan client
    session_start();
    #menghentikan perintah pada server dan client
    session_destroy();
    #pesan sukses logout
    echo "Anda telah sukses keluar sistem <b>LOGOUT</b>";
    echo "<br><a href=form_login.php><b>Login User</b></a></center>";
?>