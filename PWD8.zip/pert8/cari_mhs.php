<?php
    //Untuk koneksi ke database
    include '../pert8/koneksi.php'
?>

<!--Untuk membuat form input pencarian-->
<h3>Form Pencarian Dengan PHP MAHASISWA</h3>
    <form action="" method="get">
        <label>Cari :</label>
        <input type="text" name="cari">
        <input type="submit" value="Cari">
    </form>

<!--Untuk mengecek jika ada request-->
<?php
    if(isset($_GET['cari'])){
        //Menyimpan value get ke dalam variabel
        $cari = $_GET['cari'];
        //Menampilkan isi dari variabel
        echo "<b>Hasil pencarian : ".$cari."</b>";
    }
?>

<!--Untuk membuat table hasil pencarian-->
<table border="1">
    <tr>
        <th>No</th>
        <th>Nama</th>
    </tr>

    <?php
    //Mengecek jika ada request get cari
    if(isset($_GET['cari'])){
        //Menyimpan value get ke dalam variabel
        $cari = $_GET['cari'];
        //Fungsi untuk mencari dengan nama pada from mahasiswa
        $sql="select * from mahasiswa where nama like'%".$cari."%'";
        $tampil = mysqli_query($con,$sql);
    }else{
        //Jika tidak ada request maka data ditampilkan semuanya
        $sql="select * from mahasiswa";
        $tampil = mysqli_query($con,$sql);
    }
    //Deklarasi variabel berisi angka 1
    $no = 1;
    //Fetch data $tampil kedalam array dan akan berhenti setelah semua data di fetch
    while($r = mysqli_fetch_array($tampil)){
    ?>

    <tr>
        <td><?php echo $no++; ?></td>
        <td><?php echo $r['namaMahasiswa']; ?></td>
    </tr>
    <?php } ?>
</table>