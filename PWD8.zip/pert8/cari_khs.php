<?php
//Untuk koneksi ke database
    include '../pert8/koneksi.php';
?>

<h3>Form Pencarian DATA KHS Dengan PHP </h3>
<form action="" method="get">
    <label>Cari :</label>
    <input type="text" name="cari">
    <input type="submit" value="Cari">
</form>

<?php
//Cek jika ada request get cari
if (isset($_GET['cari'])) {
    //Menyimpan value get cari ke dalam variabel
    $cari = $_GET['cari'];
    //menampilkan isi dari variabel
    echo "<b>Hasil pencarian : " . $cari . "</b>";
}
?>

<table border="1">
    <tr>
        <th>No</th>
        <th>NIM</th>
        <th>Nama Mahasiswa</th>
        <th>Kode MK</th>
        <th>Nama Mata Kuliah</th>
        <th>Nilai</th>
    </tr>

    <?php
    //Cek jika ada request get cari
    if (isset($_GET['cari'])) {
        //Menyimpan value get cari ke dalam variabel
        $cari     = $_GET['cari'];
        //sintaks untuk pencarian data dengan variabel $cari
        $sql     = "SELECT
							mahasiswa.nim, nilai, namaMahasiswa, kode, namaMK
                            FROM khs INNER JOIN mahasiswa ON khs.NIM=mahasiswa.nim
							INNER JOIN matakuliah ON khs.kodeMK=matakuliah.kode
							WHERE mahasiswa.nim='$cari'";
        $tampil = mysqli_query($con, $sql);
    } else {
        //sintaks option untuk mencari nama berdasarkan nim
        $sql     = "SELECT
                    mahasiswa.nim, nilai, namaMahasiswa, kode, namaMK  
                    FROM khs INNER JOIN mahasiswa ON khs.NIM=mahasiswa.nim
                    INNER JOIN matakuliah ON khs.kodeMK=matakuliah.kode";
        $tampil = mysqli_query($con, $sql);
    }
    //Deklarasi variabel berisi angka 1
    $no = 1;
    //Fetch data $tampil kedalam array dan akan berhenti setelah semua data di fetch
    while ($r = mysqli_fetch_array($tampil)) {
    ?>

        <tr>
            <!--Menampilkan data-->
            <td><?php echo $no++; ?></td>
            <td><?php echo $r['nim']; ?></td>
            <td><?php echo $r['namaMahasiswa']; ?></td>
            <td><?php echo $r['kode']; ?></td>
            <td><?php echo $r['namaMK']; ?></td>
            <td><?php echo $r['nilai']; ?></td>
        </tr>

    <?php } ?>

</table>